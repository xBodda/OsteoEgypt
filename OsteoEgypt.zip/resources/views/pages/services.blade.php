@extends('layouts.app')

@section('title')
    Services
@endsection

@section('contents')
    <h1>Services Page</h1>
@endsection()
