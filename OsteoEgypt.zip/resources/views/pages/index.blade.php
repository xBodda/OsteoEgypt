@extends('layouts.app')

@section('title')
    Home
@endsection

@section('contents')
@endsection()
