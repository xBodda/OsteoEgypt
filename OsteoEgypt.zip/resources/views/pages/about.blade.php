@extends('layouts.app')

@section('title')
    About
@endsection

@section('contents')
    <h1>About Page</h1>
@endsection()